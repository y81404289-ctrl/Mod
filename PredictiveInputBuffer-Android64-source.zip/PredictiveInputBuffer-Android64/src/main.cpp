#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>
#include <Geode/modify/GameObject.hpp>
#include <Geode/modify/EffectGameObject.hpp>
#include <Geode/modify/HardStreak.hpp>
#include <algorithm>

using namespace geode::prelude;

// Android port of Predictive Input Buffer.
// The trajectory simulation and input decisions remain the same; F6 is replaced
// by an in-level touch button because mobile devices normally have no F-keys.
constexpr int SPAM_INTERVAL_TICKS = 8;
constexpr int SPAM_STREAK_REQUIRED = 3;

static CCLabelBMFont* s_presetLabel = nullptr;

class TrajectoryBufferSim {
private:
    PlayerObject* m_simPlayer1 = nullptr;
    PlayerObject* m_simPlayer2 = nullptr;
    bool m_simulating = false;
    bool m_firingBuffered = false;
    bool m_simulationDead = false;
    bool m_physicalHolding = false;
    bool m_gameHolding = false;
    int  m_presetIndex = 0;
    bool m_enabled = true;
    int  m_maxTicksNormal = 2;
    int  m_maxTicksWave = 2;
    int  m_waitTicks = -1;
    bool m_bufferedPush = true;
    bool m_queuedOpposite = false;
    float m_frameDt = 0.25f;
    int  m_ticksSinceLastInput = 999;
    int  m_rapidInputStreak = 0;

    PlayerObject* createTrajectoryPlayer() {
        PlayLayer* pl = PlayLayer::get();
        if (!pl || !pl->m_objectLayer) return nullptr;
        PlayerObject* player = PlayerObject::create(1, 1, pl, pl, true);
        if (!player) return nullptr;
        player->retain();
        player->setPosition({0.f, 105.f});
        player->setVisible(false);
        pl->m_objectLayer->addChild(player);
        return player;
    }

    void resetCollisionLog(PlayerObject* self) {
        if (!self) return;
        if (self->m_collisionLogTop) self->m_collisionLogTop->removeAllObjects();
        if (self->m_collisionLogBottom) self->m_collisionLogBottom->removeAllObjects();
        if (self->m_collisionLogLeft) self->m_collisionLogLeft->removeAllObjects();
        if (self->m_collisionLogRight) self->m_collisionLogRight->removeAllObjects();
    }

    void syncSimPlayer(PlayerObject* sim, PlayerObject* real) {
        if (!sim || !real) return;
        sim->setVisible(false);
        sim->copyAttributes(real);
        sim->setScale(real->getScale());
        sim->setContentSize(real->getContentSize());
        sim->m_width = real->m_width;
        sim->m_height = real->m_height;
        sim->m_gravityMod = real->m_gravityMod;
        sim->m_isOnGround = real->m_isOnGround;
        sim->m_isUpsideDown = real->m_isUpsideDown;
        sim->m_vehicleSize = real->m_vehicleSize;
        sim->m_playerSpeed = real->m_playerSpeed;
    }

    float getValidDt() const {
        return (m_frameDt > 0.001f && m_frameDt < 2.f) ? m_frameDt : 0.25f;
    }

    void updatePresetLabel() {
        if (!s_presetLabel) return;
        switch (m_presetIndex) {
            case 0: s_presetLabel->setString("BUF 2/2"); break;
            case 1: s_presetLabel->setString("BUF 4/4"); break;
            case 2: s_presetLabel->setString("BUF 8/8"); break;
            case 3: s_presetLabel->setString("BUF 16/8"); break;
            default: s_presetLabel->setString("BUF OFF"); break;
        }
    }

public:
    void init() {
        // Dispose of any stale simulation objects if the player restarts a level.
        quit();
        PlayLayer* pl = PlayLayer::get();
        if (!pl) return;
        m_simPlayer1 = createTrajectoryPlayer();
        m_simPlayer2 = createTrajectoryPlayer();
        m_presetIndex = 0;
        m_enabled = true;
        m_maxTicksNormal = 2;
        m_maxTicksWave = 2;
        m_waitTicks = -1;
        m_queuedOpposite = false;
        m_physicalHolding = false;
        m_gameHolding = false;
        m_simulating = false;
        m_firingBuffered = false;
        m_simulationDead = false;
        m_ticksSinceLastInput = 999;
        m_rapidInputStreak = 0;
        updatePresetLabel();
    }

    void quit() {
        if (m_simPlayer1) {
            m_simPlayer1->removeFromParentAndCleanup(false);
            m_simPlayer1->release();
            m_simPlayer1 = nullptr;
        }
        if (m_simPlayer2) {
            m_simPlayer2->removeFromParentAndCleanup(false);
            m_simPlayer2->release();
            m_simPlayer2 = nullptr;
        }
        m_simulating = false;
        m_firingBuffered = false;
        m_waitTicks = -1;
        m_queuedOpposite = false;
        m_rapidInputStreak = 0;
    }

    void cyclePreset() {
        m_presetIndex = (m_presetIndex + 1) % 5;
        m_waitTicks = -1;
        m_queuedOpposite = false;
        switch (m_presetIndex) {
            case 0:
                m_enabled = true; m_maxTicksNormal = 2; m_maxTicksWave = 2;
                log::info("[InputBuffer] Stage 1: 2 ticks all / 2 ticks Wave");
                break;
            case 1:
                m_enabled = true; m_maxTicksNormal = 4; m_maxTicksWave = 4;
                log::info("[InputBuffer] Stage 2: 4 ticks all / 4 ticks Wave");
                break;
            case 2:
                m_enabled = true; m_maxTicksNormal = 8; m_maxTicksWave = 8;
                log::info("[InputBuffer] Stage 3: 8 ticks all / 8 ticks Wave");
                break;
            case 3:
                m_enabled = true; m_maxTicksNormal = 16; m_maxTicksWave = 8;
                log::info("[InputBuffer] Stage 4: 16 ticks all / 8 ticks Wave");
                break;
            default:
                m_enabled = false; m_maxTicksNormal = 0; m_maxTicksWave = 0;
                log::info("[InputBuffer] Stage 5: OFF");
                break;
        }
        updatePresetLabel();
    }

    bool isSimulating() const { return m_simulating; }
    bool isFiringBuffered() const { return m_firingBuffered; }

    bool checkSimulationDeath(PlayerObject* player) {
        if (m_simulating && (player == m_simPlayer1 || player == m_simPlayer2)) {
            m_simulationDead = true;
            return true;
        }
        m_waitTicks = -1;
        m_queuedOpposite = false;
        m_gameHolding = false;
        m_rapidInputStreak = 0;
        return false;
    }

    void setFrameDelta(float dt) {
        PlayLayer* pl = PlayLayer::get();
        if (pl && pl->m_gameState.m_timeWarp > 0.f)
            m_frameDt = dt / pl->m_gameState.m_timeWarp;
        else
            m_frameDt = dt;
    }

    int getSurvivalTicks(PlayLayer* pl, PlayerObject* realP1, PlayerObject* realP2,
                         bool isDual, int delayFrames, bool actionPush, int maxTicks) {
        if (!pl || !m_simPlayer1 || !realP1) return maxTicks;
        m_simulating = true;
        m_simulationDead = false;
        syncSimPlayer(m_simPlayer1, realP1);
        if (isDual && m_simPlayer2 && realP2) syncSimPlayer(m_simPlayer2, realP2);

        if (delayFrames > 0) {
            if (!actionPush) {
                m_simPlayer1->pushButton(PlayerButton::Jump);
                if (isDual && m_simPlayer2) m_simPlayer2->pushButton(PlayerButton::Jump);
            } else {
                m_simPlayer1->releaseButton(PlayerButton::Jump);
                if (isDual && m_simPlayer2) m_simPlayer2->releaseButton(PlayerButton::Jump);
            }
        }

        float dt = getValidDt();
        int survived = 0;
        bool isContinuousMode = realP1->m_isDart || realP1->m_isBird || realP1->m_isSwing ||
            (isDual && realP2 && (realP2->m_isDart || realP2->m_isBird || realP2->m_isSwing));
        int airborneTicks = 0;
        int safeLandedTicks = 0;

        for (int i = 0; i < delayFrames + maxTicks; i++) {
            if (i == delayFrames) {
                if (actionPush) {
                    m_simPlayer1->pushButton(PlayerButton::Jump);
                    if (isDual && m_simPlayer2) m_simPlayer2->pushButton(PlayerButton::Jump);
                } else {
                    m_simPlayer1->releaseButton(PlayerButton::Jump);
                    if (isDual && m_simPlayer2) m_simPlayer2->releaseButton(PlayerButton::Jump);
                }
            }
            m_simPlayer1->update(dt);
            m_simPlayer1->updateRotation(dt);
            if (isDual && m_simPlayer2) {
                m_simPlayer2->update(dt);
                m_simPlayer2->updateRotation(dt);
            }
            if (m_simulationDead) break;

            resetCollisionLog(m_simPlayer1);
            pl->checkCollisions(m_simPlayer1, dt, false);
            if (m_simulationDead) break;
            if (isDual && m_simPlayer2 && realP2) {
                resetCollisionLog(m_simPlayer2);
                pl->checkCollisions(m_simPlayer2, dt, false);
                if (m_simulationDead) break;
            }

            if (i >= delayFrames) {
                survived++;
                if (!isContinuousMode) {
                    bool p1Grounded = m_simPlayer1->m_isOnGround;
                    bool p2Grounded = (!isDual || !m_simPlayer2) ? true : m_simPlayer2->m_isOnGround;
                    if (!p1Grounded || !p2Grounded) {
                        airborneTicks++;
                        safeLandedTicks = 0;
                    } else if (airborneTicks >= 15) {
                        safeLandedTicks++;
                        if (safeLandedTicks >= 10) {
                            survived = maxTicks;
                            break;
                        }
                    }
                }
            }
        }
        m_simulating = false;
        return survived;
    }

    bool interceptInput(GJBaseGameLayer* layer, bool push, bool isPlayer1) {
        PlayLayer* pl = PlayLayer::get();
        if (!pl) return true;
        bool isDual = pl->m_gameState.m_isDualMode && pl->m_player2 != nullptr;
        bool isTwoPlayerControl = pl->m_level && pl->m_level->m_twoPlayerMode;
        if (!isPlayer1) {
            if (isDual && !isTwoPlayerControl && (m_waitTicks >= 0 || m_waitTicks == -2)) return false;
            return true;
        }
        m_physicalHolding = push;
        if (!m_enabled) { m_gameHolding = push; return true; }
        PlayerObject* p1 = layer->m_player1;
        PlayerObject* p2 = isDual ? pl->m_player2 : nullptr;
        if (!p1 || p1->m_isDead) {
            m_waitTicks = -1; m_queuedOpposite = false; m_gameHolding = push; return true;
        }
        if (p1->m_isShip || (isDual && p2 && p2->m_isShip)) {
            m_waitTicks = -1; m_queuedOpposite = false; m_gameHolding = push; return true;
        }
        if (m_waitTicks >= 0) {
            m_queuedOpposite = (push != m_bufferedPush);
            m_ticksSinceLastInput = 0;
            return false;
        }
        if (m_waitTicks == -2) {
            m_waitTicks = -1;
            m_queuedOpposite = false;
            if (m_gameHolding != !m_bufferedPush) m_SimFireButton(pl, !m_bufferedPush);
        }
        bool isWave = p1->m_isDart || (isDual && p2 && p2->m_isDart);
        bool isMiniWave = (p1->m_isDart && p1->m_vehicleSize < 1.f) ||
            (isDual && p2 && p2->m_isDart && p2->m_vehicleSize < 1.f);
        if (m_ticksSinceLastInput < SPAM_INTERVAL_TICKS) ++m_rapidInputStreak;
        else m_rapidInputStreak = 0;
        m_ticksSinceLastInput = 0;
        if (isWave && m_rapidInputStreak >= SPAM_STREAK_REQUIRED) {
            m_gameHolding = push;
            return true;
        }
        bool releaseAffectsPhysics = p1->m_isDart || p1->m_isRobot ||
            (isDual && p2 && (p2->m_isDart || p2->m_isRobot));
        if (!push && !releaseAffectsPhysics) { m_gameHolding = false; return true; }
        m_queuedOpposite = false;
        const char* act = push ? "PRESS" : "RELEASE";
        int targetHorizon = isMiniWave ? 50 : (isWave ? 65 : 160);
        int maxDelayFrames = isWave ? m_maxTicksWave : m_maxTicksNormal;
        int ticksFrame0 = getSurvivalTicks(pl, p1, p2, isDual, 0, push, targetHorizon);
        if (ticksFrame0 >= targetHorizon) { m_gameHolding = push; return true; }
        int bestDelay = 0;
        int bestTicks = ticksFrame0;
        for (int delay = 1; delay <= maxDelayFrames; delay++) {
            int ticks = getSurvivalTicks(pl, p1, p2, isDual, delay, push, targetHorizon);
            if (isWave) {
                int minClearedGain = (delay * 2) + 10;
                if (ticks >= targetHorizon && (ticks - ticksFrame0) >= (delay * 2) + 6) {
                    bestDelay = delay; bestTicks = ticks; break;
                }
                if (ticks >= ticksFrame0 + minClearedGain && ticks > bestTicks + 2) {
                    bestDelay = delay; bestTicks = ticks;
                    if (ticks >= targetHorizon) break;
                }
            } else {
                if (ticks >= targetHorizon) { bestDelay = delay; bestTicks = ticks; break; }
                if (ticks > bestTicks + 12) { bestDelay = delay; bestTicks = ticks; }
            }
        }
        if (bestDelay > 0) {
            log::info("[InputBuffer] Saved +{} ticks ({:.2f} frames @ 60fps) {}! Frame0 {} -> delayed {} [limit {}]",
                bestDelay, bestDelay / 4.f, act, ticksFrame0, bestTicks, maxDelayFrames);
            m_bufferedPush = push;
            m_waitTicks = bestDelay;
            return false;
        }
        m_gameHolding = push;
        return true;
    }

    void onPlayerUpdate(PlayerObject* player) {
        PlayLayer* pl = PlayLayer::get();
        if (!pl || player != pl->m_player1) return;
        if (!m_enabled) return;
        if (m_ticksSinceLastInput < 999) ++m_ticksSinceLastInput;
        if (player->m_isShip || (pl->m_gameState.m_isDualMode && pl->m_player2 && pl->m_player2->m_isShip)) {
            m_waitTicks = -1;
            m_queuedOpposite = false;
            if (m_gameHolding != m_physicalHolding) m_SimFireButton(pl, m_physicalHolding);
            return;
        }
        if (m_waitTicks == 0) {
            m_SimFireButton(pl, m_bufferedPush);
            if (m_queuedOpposite) { m_waitTicks = -2; m_queuedOpposite = false; }
            else m_waitTicks = -1;
        } else if (m_waitTicks > 0) {
            --m_waitTicks;
        } else if (m_waitTicks == -2) {
            m_SimFireButton(pl, !m_bufferedPush);
            m_queuedOpposite = false;
            m_waitTicks = -1;
        } else if (m_waitTicks == -1 && m_gameHolding != m_physicalHolding) {
            m_SimFireButton(pl, m_physicalHolding);
        }
    }

    void m_SimFireButton(PlayLayer* pl, bool push) {
        m_firingBuffered = true;
        m_gameHolding = push;
        pl->handleButton(push, 1, true);
        if (pl->m_gameState.m_isDualMode && (!pl->m_level || !pl->m_level->m_twoPlayerMode))
            pl->handleButton(push, 1, false);
        m_firingBuffered = false;
    }
};

static TrajectoryBufferSim s_sim;

$on_mod(Loaded) {
    log::info("Predictive Input Buffer Android port loaded");
    log::info("Tap the BUF button in-game to cycle: 2/2 -> 4/4 -> 8/8 -> 16/8 -> OFF");
}

class $modify(BufPlayLayer, PlayLayer) {
    static void onModify(auto& self) {
        (void)self.setHookPriority("PlayLayer::destroyPlayer", -1000000);
        (void)self.setHookPriority("PlayLayer::playEndAnimationToPos", -1000000);
        (void)self.setHookPriority("PlayLayer::flipGravity", -1000000);
    }

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        s_sim.init();
        createBufferButton();
        return true;
    }

    void createBufferButton() {
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        if (!menu) return;
        menu->setPosition({0.f, 0.f});
        auto buttonSprite = CCSprite::createWithSpriteFrameName("GJ_button_01.png");
        if (!buttonSprite) buttonSprite = CCSprite::create("GJ_button_01.png");
        if (!buttonSprite) {
            log::warn("[InputBuffer] Could not create the touch button sprite");
            return;
        }
        buttonSprite->setScale(0.75f);
        s_presetLabel = CCLabelBMFont::create("BUF 2/2", "bigFont.fnt");
        if (!s_presetLabel) return;
        s_presetLabel->setScale(0.42f);
        s_presetLabel->setPosition({buttonSprite->getContentSize().width / 2.f,
                                    buttonSprite->getContentSize().height / 2.f});
        buttonSprite->addChild(s_presetLabel, 2);
        auto item = CCMenuItemSpriteExtra::create(
            buttonSprite, this, menu_selector(BufPlayLayer::onCyclePreset));
        if (item) {
            // Top-left avoids the in-game pause button on the upper-right.
            item->setPosition({68.f, winSize.height - 62.f});
            menu->addChild(item);
            this->addChild(menu, 10000);
        }
    }

    void onCyclePreset(CCObject*) { s_sim.cyclePreset(); }

    void destroyPlayer(PlayerObject* player, GameObject* gameObject) {
        if (s_sim.checkSimulationDeath(player)) return;
        PlayLayer::destroyPlayer(player, gameObject);
    }
    void playEndAnimationToPos(cocos2d::CCPoint p0) {
        if (s_sim.isSimulating()) return;
        PlayLayer::playEndAnimationToPos(p0);
    }
    void flipGravity(PlayerObject* p0, bool p1, bool p2) {
        if (s_sim.isSimulating()) return;
        PlayLayer::flipGravity(p0, p1, p2);
    }
    void onQuit() {
        s_presetLabel = nullptr;
        PlayLayer::onQuit();
        s_sim.quit();
    }
};

class $modify(BufEditorLayer, LevelEditorLayer) {
    bool init(GJGameLevel* level, bool unk) {
        bool res = LevelEditorLayer::init(level, unk);
        s_presetLabel = nullptr;
        s_sim.quit();
        return res;
    }
};

class $modify(BufHardStreak, HardStreak) {
    static void onModify(auto& self) { (void)self.setHookPriority("HardStreak::addPoint", -1000000); }
    void addPoint(cocos2d::CCPoint p0) {
        if (s_sim.isSimulating()) return;
        HardStreak::addPoint(p0);
    }
};

class $modify(BufEffectGameObject, EffectGameObject) {
    static void onModify(auto& self) { (void)self.setHookPriority("EffectGameObject::triggerObject", -1000000); }
    void triggerObject(GJBaseGameLayer* p0, int p1, const gd::vector<int>* p2) {
        if (s_sim.isSimulating()) return;
        EffectGameObject::triggerObject(p0, p1, p2);
    }
};

class $modify(BufGameObject, GameObject) {
    static void onModify(auto& self) { (void)self.setHookPriority("GameObject::playShineEffect", -1000000); }
    void playShineEffect() {
        if (s_sim.isSimulating()) return;
        GameObject::playShineEffect();
    }
};

class $modify(BufPlayerObject, PlayerObject) {
    static void onModify(auto& self) {
        (void)self.setHookPriority("PlayerObject::playSpiderDashEffect", -1000000);
        (void)self.setHookPriority("PlayerObject::incrementJumps", -1000000);
        (void)self.setHookPriority("PlayerObject::ringJump", -1000000);
    }
    void playSpiderDashEffect(cocos2d::CCPoint from, cocos2d::CCPoint to) {
        if (s_sim.isSimulating()) return;
        PlayerObject::playSpiderDashEffect(from, to);
    }
    void incrementJumps() {
        if (s_sim.isSimulating()) return;
        PlayerObject::incrementJumps();
    }
    void update(float dt) {
        if (!s_sim.isSimulating()) s_sim.onPlayerUpdate(this);
        PlayerObject::update(dt);
        if (PlayLayer::get() && !s_sim.isSimulating()) s_sim.setFrameDelta(dt);
    }
    void ringJump(RingObject* p0, bool p1) {
        if (s_sim.isSimulating()) return;
        PlayerObject::ringJump(p0, p1);
    }
};

class $modify(BufBaseGameLayer, GJBaseGameLayer) {
    static void onModify(auto& self) {
        (void)self.setHookPriority("GJBaseGameLayer::canBeActivatedByPlayer", -1000000);
        (void)self.setHookPriority("GJBaseGameLayer::handleButton", -1000000);
        (void)self.setHookPriority("GJBaseGameLayer::collisionCheckObjects", -1000000);
        (void)self.setHookPriority("GJBaseGameLayer::playerTouchedRing", -1000000);
    }
    bool canBeActivatedByPlayer(PlayerObject* p0, EffectGameObject* p1) {
        if (s_sim.isSimulating()) return false;
        return GJBaseGameLayer::canBeActivatedByPlayer(p0, p1);
    }
    void handleButton(bool down, int button, bool isPlayer1) {
        if (!s_sim.isSimulating() && !s_sim.isFiringBuffered() && button == 1 && PlayLayer::get()) {
            if (!s_sim.interceptInput(this, down, isPlayer1)) return;
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
    void collisionCheckObjects(PlayerObject* player, gd::vector<GameObject*>* vec, int objectsCount, float dt) {
        if (s_sim.isSimulating()) {
            gd::vector<GameObject*> extra;
            extra.reserve(objectsCount);
            for (int i = 0; i < objectsCount; ++i) {
                GameObject* obj = vec->at(i);
                if (!obj) continue;
                if (obj->m_objectType == GameObjectType::Solid ||
                    obj->m_objectType == GameObjectType::Hazard ||
                    obj->m_objectType == GameObjectType::AnimatedHazard ||
                    obj->m_objectType == GameObjectType::CollisionObject ||
                    obj->m_objectType == GameObjectType::Slope) {
                    extra.push_back(obj);
                }
            }
            GJBaseGameLayer::collisionCheckObjects(player, &extra, static_cast<int>(extra.size()), dt);
            return;
        }
        GJBaseGameLayer::collisionCheckObjects(player, vec, objectsCount, dt);
    }
    void playerTouchedRing(PlayerObject* player, RingObject* ring) {
        if (s_sim.isSimulating()) return;
        GJBaseGameLayer::playerTouchedRing(player, ring);
    }
};
