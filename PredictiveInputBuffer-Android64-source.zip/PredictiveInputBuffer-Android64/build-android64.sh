#!/usr/bin/env sh
set -eu

if ! command -v geode >/dev/null 2>&1; then
  echo "Geode CLI was not found. Install Geode CLI and the Android NDK first." >&2
  exit 1
fi

geode sdk install-binaries -p android64
geode build -p android64
