# Predictive Input Buffer — Android ARM64 source project

This is an Android-oriented Geode project port based on the supplied Predictive Input Buffer source. Windows-only headers, F6 polling, and Windows console setup have been removed. A touch button labelled `BUF` cycles through `2/2 -> 4/4 -> 8/8 -> 16/8 -> OFF`.

## Build for Android 64-bit

A compiled `.geode` package cannot be created without the matching Geode SDK binaries and Android NDK. Install Geode CLI + Android NDK on a build machine and run:

```sh
geode sdk install-binaries -p android64
geode build -p android64
```

The resulting package should be under `build-android64/`. Copy the `.geode` file to:

`/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`

Restart/reload Geode after copying it. This project targets Geometry Dash Android `2.2081` and Geode `5.11.2` as set in `mod.json`.

## Automatic GitHub build

The workflow in `.github/workflows/build-android64.yml` builds Android64 on GitHub Actions and uploads the generated `.geode` file as an artifact. To use it, upload this project folder to a GitHub repository and enable Actions.

## Important status

This is a source port, not a precompiled `.geode` package. The current environment did not contain the Geode SDK or Android NDK, so the native build and in-game behavior have not been compiler- or device-verified. Check the build log for SDK/API mismatches before installing on a device.
